package com.example.chuck;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.example.chuck.model.Response;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
     Button button;
     ProgressBar progressBar;
     TextView mainText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = findViewById(R.id.button);
        progressBar = findViewById(R.id.progressBar);
        mainText = findViewById(R.id.textView);

        myRequest();

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myRequest();
            }
        });





    }

    void myRequest(){
        loader(true);
        AndroidNetworking.get("https://api.chucknorris.io/jokes/random")
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {

                        Gson gson = new Gson();
                        Response object = gson.fromJson(response.toString(),Response.class);

                        mainText.setText(object.value);


                        loader(false);



                    }

                    @Override
                    public void onError(ANError anError) {
                        loader(false);
                        mainText.setText("An Error Occurred Please Retry");
                        button.setText("retry");

                    }
                });

    }


     void loader(Boolean loading){

        if(loading){
             progressBar.setVisibility(View.VISIBLE);
             button.setVisibility(View.GONE);
             mainText.setText("Loading . . .");
             button.setText("next");

        }else{
            progressBar.setVisibility(View.GONE);
            button.setVisibility(View.VISIBLE);
        }

    }
}