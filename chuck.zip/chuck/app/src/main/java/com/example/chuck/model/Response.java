package com.example.chuck.model;

public class Response {

    //                        {
//                            "icon_url" : "https://assets.chucknorris.host/img/avatar/chuck-norris.png",
//                                "id" : "eogk64wnR7iK2X5XXa4zDQ",
//                                "url" : "",
//                                "value" : "Chuck Norris can just wright a random number and the math problem is right"
//}

    public String icon_url;
    public String id;
    public String url;
    public String value;

}
